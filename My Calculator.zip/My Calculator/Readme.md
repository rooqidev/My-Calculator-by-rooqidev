// MyCalculator

A simple calculator built with HTML, CSS, and JavaScript.

🚀 Features

//Basic operations: add, subtract, multiply, divide

Clear & reset

Custom evaluation function (built without using eval())

//-----